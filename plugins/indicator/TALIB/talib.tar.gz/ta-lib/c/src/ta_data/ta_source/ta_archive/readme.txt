This speed optimized/binary data source is under development.
Not integrated in the TA-LIB yet.

This data source will offer specialize data compression
for faster IO transfer. Specialize means that the compressor
is specifically designed to compress financial price bars.